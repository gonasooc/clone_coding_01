$(document).ready(function(){
    $('#header .header_inner .gnb').mouseenter(function(){
        $('.gnb_fulldown').stop().slideDown();
        $('.depth2').stop().slideDown();
    });
    $('#header .header_inner .gnb').mouseleave(function(){
        $('.gnb_fulldown').stop().slideUp();
        $('.depth2').stop().slideUp();
    });

    




    var footer_sw = true;
    $('#footer button').click(function(){
        if(footer_sw){
            $('#footer button').removeClass('on');
            $('#footer .family-box').removeClass('on');
            $(this).addClass('on');
            $(this).parent().find('.family-box').addClass('on');
            footer_sw = false;
        } else {
            $(this).removeClass('on');
            $(this).parent().find('.family-box').removeClass('on');
            footer_sw = true;
        }
    });

    $('#footer .close_btn').click(function(){
        $('#footer .family-box').removeClass('on');
        $('#footer button').removeClass('on');
        $('#footer .family-box').removeClass('on');
        sw = true;
    });




})